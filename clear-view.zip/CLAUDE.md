# CLAUDE.md

This file provides guidance to Claude Code when working with code in this repository.

## What this project is

`clear-view` is a Windows screen magnifier (ZoomText alternative) written in Rust. It uses DXGI Desktop Duplication for screen capture, GDI StretchBlt for rendering, and egui for the settings panel.

See `PLAN.md` for the full architecture and phased roadmap.

## Build & run
```bash
cargo build
cargo run
cargo build --release
```

Windows-only. Will not compile on other platforms.

## Architecture

Four concurrent threads sharing `Arc<RwLock<AppState>>`:

- **Main thread** — runs `eframe` (egui settings panel) with `with_always_on_top()`
- **Capture thread** (`cv-capture`) — DXGI Desktop Duplication → D3D11 staging texture → CPU `Vec<u8>` (BGRA8) readback, stored in `Arc<Mutex<Option<Arc<Frame>>>>`
- **Render thread** (`cv-render`) — GDI overlay window driven by `WM_TIMER` (16ms); lerps cursor, crops frame region, `StretchBlt` to fullscreen
- **Hotkey thread** — `RegisterHotKey` (Win+=) toggles `AppState.enabled`; renderer shows/hides via `ShowWindow`

## Key design decisions

- **Self-capture prevention**: `SetWindowDisplayAffinity(WDA_EXCLUDEFROMCAPTURE)` prevents the overlay appearing in its own DXGI capture.
- **Overlay flags**: `WS_POPUP | WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE | WS_EX_LAYERED` — clicks pass through, window stays on top.
- **Overlay starts hidden**: Created without `WS_VISIBLE`. `WM_TIMER` calls `ShowWindow(SW_SHOW/SW_HIDE)` on enabled state change.
- **GDI rendering**: D3D11 immediate context is NOT thread-safe. The GPU pipeline was replaced with DXGI → staging texture CPU readback → GDI `StretchBlt`. Do not attempt to share `ID3D11DeviceContext` between threads.
- **Smooth follow**: Frame-rate-independent lerp: `alpha = 1.0 - (1.0 - smooth_speed).powf(dt * 60.0)`
- **Interpolation**: Bilinear active via GDI. Lanczos is a greyed-out placeholder in egui for a future phase.
- **windows crate**: Use version 0.62. API signatures differ significantly from 0.58. `D3D11CreateDevice` software param is `HMODULE::default()` not `None`.
- **Rust 2024 edition**: Requires explicit `unsafe {}` blocks inside `unsafe fn` bodies.

## Dead ends — do not retry these approaches

- **D3D11 shared device context**: Tried and failed. Immediate context is single-threaded. Frames never rendered. Use CPU readback instead.
- **ClipCursor**: Do not use under any circumstances. Blocks user from half the screen with no way to interact with content in that region.
- **Mixing screen-space and frame-space coordinates**: Always ensure cursor coords and frame coords are in the same space before any layout math.

## DXGI error handling

| Error | Action |
|---|---|
| `DXGI_ERROR_WAIT_TIMEOUT` | Retry `AcquireNextFrame` |
| `DXGI_ERROR_ACCESS_LOST` | Re-create `IDXGIOutputDuplication` |
| `DXGI_ERROR_DEVICE_REMOVED` | Re-create D3D11 device and all resources |

## Windows crate

Use the `windows` crate (not `winapi` or `windows-sys`). Add new features to the `windows` dependency in `Cargo.toml` rather than pulling in separate FFI crates. `RegisterHotKey`, `MOD_WIN`, `VK_OEM_PLUS` are in `Win32::UI::Input::KeyboardAndMouse`, not `WindowsAndMessaging`.

## Planned phases

1. ✅ Full-screen magnification
2. AppBar docked panel — `SHAppBarMessage`, all four edges (ABE_TOP/BOTTOM/LEFT/RIGHT), desktop work area shifts to accommodate
3. Panning 1:1 view alongside magnified view in docked panel
4. Colour filters (inverted, greyscale, greyscale+inverted)
5. Cursor enhancement (larger cursor, highlighting)
6. TTS / screen reader
7. Multi-monitor